text_id = "";
