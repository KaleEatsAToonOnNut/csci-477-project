global.font_main = font_add_sprite(sMainFont, 32, true, 1);

